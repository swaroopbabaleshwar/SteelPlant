module.exports = {
    DEVICE: {
        DOMAIN: 'http://aic-arm.azurewebsites.net',
        DEVICETYPES: 'https://aic-arm.azurewebsites.net/DeviceTypes'
    }
}