import RESTAPI from './service';

export default RESTAPI;