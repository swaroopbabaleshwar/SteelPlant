import React from 'react';
import CustomLayout from './Layout/Layout';
import './App.css';

function App() {
  return (
    <div className="App">
      <CustomLayout />
    </div>
  );
}

export default App;
