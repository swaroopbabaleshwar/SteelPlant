import React, { Component } from 'react';

class RecipeTable extends Component {
    constructor() {
        super();
    }

    render() {
        return(
            <>
                <div>RecidiveTable</div>
            </>
        );
    }
}

export default RecipeTable;