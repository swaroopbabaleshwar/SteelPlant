import React, { Component } from 'react';

class HMIOverview extends Component {
    constructor() {
        super();
    }

    render() {
        return(
            <>
                <div>HMIOverview</div>
            </>
        );
    }
}

export default HMIOverview;