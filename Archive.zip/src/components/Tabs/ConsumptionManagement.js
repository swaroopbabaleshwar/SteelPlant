import React, { Component } from 'react';

class ConsumptionManagement extends Component {
    constructor() {
        super();
    }

    render() {
        return(
            <>
                <div>ConsumdivtionManagement</div>
            </>
        );
    }
}

export default ConsumptionManagement;