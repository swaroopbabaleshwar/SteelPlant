import React, { Component } from 'react';

class StorageManagement extends Component {
    constructor() {
        super();
    }

    render() {
        return(
            <>
                <div>StorageManagement</div>
            </>
        );
    }
}

export default StorageManagement;