import React, { Component } from 'react';

class PlantData extends Component {
    constructor() {
        super();
    }

    render() {
        return(
            <>
                <div>divlantData</div>
            </>
        );
    }
}

export default PlantData;