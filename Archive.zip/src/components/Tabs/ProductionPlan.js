import React, { Component } from 'react';

class ProductionPlan extends Component {
    constructor() {
        super();
    }

    render() {
        return(
            <>
                <div>divroductiondivlan</div>
            </>
        );
    }
}

export default ProductionPlan;